#include <iostream>
#include <string>

using namespace std;

int main()
{
    // initial variables
    // one for initial value
    // one for the encoded value
    string word, encoded = "";

    cout << "Here's a sample cipher! ";
    cout << "We're shifting left by 8 to encode in this sample." << endl;

    cout << endl << "Enter in a word/phase to encode: ";
    getline(cin, word);

    // iterates through the entire word
    for(int i = 0; i < word.size(); i++)
    {
        // grabs currently indexed letter
        char letter = word[i];

        // checks range of alphabet characters
        // ignores things that aren't letters
        if((letter >= 'A' && letter <= 'Z') || (letter >= 'a' && letter <= 'z'))
        {
            // A - H and a - h
            if((letter >= 'A' && letter <= 'H') || (letter >= 'a' && letter <= 'h'))
            {
                letter += 18;
            }

            // all other letters
            else
            {
                letter -= 8;
            }
        }

        // builds encoded word
        encoded += letter;
    }

    cout << endl << "Starting point: " << word << endl;
    cout << "Ending point: " << encoded << endl;

    return 0;
}